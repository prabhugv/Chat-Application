from __future__ import unicode_literals

from django.db import models

class User(models.Model):
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    mobile=models.CharField(max_length=100)
    
class Student(models.Model):
	GENDER_CHOICES=[('male','Male'),('female','Female')]
	LOCATION_CHOICES = (('d', 'Draft'),('a', 'Approved'),)
	username = models.CharField(max_length=256)
	password = models.CharField(max_length=256)
	retype_password = models.CharField(max_length=256)
	dob=models.DateField('date of birth')
	gender = models.CharField(max_length=500, choices=GENDER_CHOICES)
	location = models.CharField(max_length=500, choices=LOCATION_CHOICES)
	phone_no = models.CharField(max_length=15)  
    
