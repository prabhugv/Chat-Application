from django.conf.urls import url
from . import views
 
app_name = 'users'
 
urlpatterns = [
 
    # /users/signup:url to take the input from the user
    url(r'^signup$', views.signup, name='signup'),
    #/users/showdata:url to display the list of users stored on the database
    url(r'^showdata$', views.showdata, name='showdata'),
    url(r'^student_detail$', views.student_detail, name='student_detail'), 
    url(r'^add_student_detail$', views.add_student_detail, name='add_student_detail'),
]
