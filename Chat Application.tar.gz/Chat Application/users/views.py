from django.shortcuts import render
from users.forms import UserForm
from users.forms import StudentForm
from users.models import User
from users.models import Student
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse

 
#the function executes with the signup url to take the inputs 
def signup(request):
    if request.method == 'POST':  # if the form has been filled
 
        form = UserForm(request.POST)
 
        if form.is_valid():  # All the data is valid
            username = request.POST.get('username', '')
            email = request.POST.get('email', '')
        password = request.POST.get('password', '')
        gender = request.POST.get('gender', '') 
        mobile = request.POST.get('mobile', '')
        # creating an user object containing all the data
        user_obj = User(username=username, email=email, password=password, gender=gender,mobile=mobile)
        # saving all the data in the current object into the database
        user_obj.save()
 
        return render(request, 'users/showdata.html', {'user_obj': user_obj,'is_registered':True }) # Redirect after POST
 
    else:
        form = UserForm()  # an unboundform
 
        return render(request, 'users/signup.html', {'form': form})

#the function executes with the showdata url to display the list of registered users
def showdata(request):
    all_users = User.objects.all()
    return render(request, 'users/showdata.html', {'all_users': all_users, })
    
def student_detail(request):
	all_user = User.objects.all()
	return render(request, 'users/student_detail.html', {'all_user': all_user, })
def add_student_detail(request):
    if request.method == 'GET':
        form = StudentForm()
    else:
        form = StudentForm(request.POST) 
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            retype_password = form.cleaned_data['retype_password']
            dob = form.cleaned_data['dob']
            gender = form.cleaned_data['gender']
            location = form.cleaned_data['location']
            phone_no = form.cleaned_data['phone_no']
            register = Student.objects.create(username=username,password=password,retype_password=retype_password,
												dob=dob,gender=gender,location=location,
                                         phone_no=phone_no)
            return HttpResponseRedirect('')
 
    return render(request, 'users/add_student_detail.html', {
        'form': form,
    })
