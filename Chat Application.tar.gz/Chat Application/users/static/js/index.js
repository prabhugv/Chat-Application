function submitForm() {
   var frm = document.getElementsByName('add_student')[0];
   frm.submit(); 
   frm.reset(); 
   return false; 
}
