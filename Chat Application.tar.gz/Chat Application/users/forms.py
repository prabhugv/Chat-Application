from django import forms
from users.models import Student


class UserForm(forms.Form):
    #to take the input of username
    username = forms.CharField(max_length=100)
    # to take the input of email
    email = forms.CharField(max_length=100)
    # to take the input of password
    password = forms.CharField(max_length=100) 
    gender=forms.CharField(max_length=100)
    mobile=forms.IntegerField()


GENDER_CHOICES=[('male','Male'),('female','Female')]
LOCATION_CHOICES = (('d', 'Draft'),('a', 'Approved'),)

class StudentForm(forms.Form):
	
	username = forms.CharField(max_length=256)
	password = forms.CharField(max_length=256)
	retype_password = forms.CharField(max_length=256)
	dob = forms.DateTimeField()
	gender = forms.ChoiceField(choices=GENDER_CHOICES, required=True )
	location = forms.ChoiceField(choices=LOCATION_CHOICES, required=True )
	phone_no = forms.RegexField(regex=r'^\+?1?\d{9,15}$', 
	error_message = ("Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed."))
	class Meta:
		model = Student
        widgets = {
            'password': forms.PasswordInput(),
        }
    
#~ CATEGORIES = (  
    #~ ('LAB', 'labor'),
    #~ ('CAR', 'cars'),
    #~ ('TRU', 'trucks'),
    #~ ('WRI', 'writing'),
#~ )
#~ LOCATIONS = (  
    #~ ('BRO', 'Bronx'),
    #~ ('BRK', 'Brooklyn'),
    #~ ('QNS', 'Queens'),
    #~ ('MAN', 'Manhattan'),
#~ )

#~ class PostAdForm(forms.ModelForm):  
    #~ error_css_class = 'error'
#~ 
    #~ category = forms.ChoiceField(choices=CATEGORIES, required=True )
    #~ location = forms.ChoiceField(choices=LOCATIONS, required=True )

