# Mirrors items reused server-side from constants.js

LOGIN_SUCCESS = 'LOGIN_SUCCESS'
RECEIVE_ROOMS = 'RECEIVE_ROOMS'
