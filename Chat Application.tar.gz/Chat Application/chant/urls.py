# -*- coding: utf-8 -*-
from django.conf.urls import include, url
from chant import views
from django.core.urlresolvers import reverse

urlpatterns = [
    url(r'^rooms/$', views.list_rooms, name='list_rooms'),
    url(r'^rooms/edit/(?:(?P<room_id>\d+)/)?$', views.edit_room, name='edit_room'),
    url(r'^rooms/delete/(?P<room_id>\d+)/$', views.delete_room, name='delete_room'),

    url(r'^rooms/(?P<room_id>\d+)/add/subscriber/$', views.add_subscriber, name='add_subscriber'),
    url(r'^rooms/(?P<room_id>\d+)/subscribers/delete/(?P<user_id>\d+)/$', views.delete_subscriber, name='delete_subscriber'),
]
