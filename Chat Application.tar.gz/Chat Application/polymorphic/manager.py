# For compatibility with pre 0.8 versions
from .managers import PolymorphicQuerySet, PolymorphicManager  # noqa
