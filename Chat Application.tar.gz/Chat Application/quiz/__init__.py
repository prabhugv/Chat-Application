default_app_conf = 'quiz.apps.QuizAppConf'
